package AbstractFactoryPattern;

public abstract class AbstractFactory {
	public abstract Vehicle getVehicle(VehicleType vehicle, String name) ;
}