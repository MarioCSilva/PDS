package AbstractFactoryPattern;

public class Bicycle extends Vehicle {
	public Bicycle(String name) {
		super(name, 500.5);
	}
}