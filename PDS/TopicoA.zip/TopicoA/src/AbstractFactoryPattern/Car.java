package AbstractFactoryPattern;

public class Car extends Vehicle {
	public Car(String name) {
		super(name, 2502.99);
	}
}