package AbstractFactoryPattern;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Map.Entry;

public class Client {
	public static void main(String[] args) {
		// create a Stand
		Stand stand = new Stand("Stand Automoveis 1998");
		
		// create abstract factories for vehicles with two and four wheels
		AbstractFactory twoWheelFactory = FactoryProducer.getVehicleFactory(VehicleFactoryType.TWOWHEEL);
	    AbstractFactory fourWheelFactory = FactoryProducer.getVehicleFactory(VehicleFactoryType.FOURWHEEL);
	    if (twoWheelFactory == null || fourWheelFactory == null) {
            System.out.println("Factory for given type doesn't exist or the type isn't valid.");
            System.exit(1);
	    }

	    // get a Four Wheel Vehicle - Car
	    Vehicle car = fourWheelFactory.getVehicle(VehicleType.CAR, "Fiat 500X");
	    // add Car to the Stand
	    stand.addVehicle(car);

	    // get Two Wheel Vehicle - Motorcycle
	    Vehicle motorcycle = twoWheelFactory.getVehicle(VehicleType.MOTORCYCLE, "Kawasaki Ninja 400");
	    // add Motorcycle to the Stand
	    stand.addVehicle(motorcycle);

	    // get a Four Wheel Vehicle - Van
	    Vehicle van = fourWheelFactory.getVehicle(VehicleType.VAN,"Honda Odyssey Van");
	    // add Van to the Stand
	    stand.addVehicle(van);

	    // get Two Wheel Vehicle - Bicycle
	    Vehicle bicycle = twoWheelFactory.getVehicle(VehicleType.BICYCLE,"Diamondback Bike");
	    // add Bicycle to the Stand
	    stand.addVehicle(bicycle);
	    
	    
	    // give the opportunity for the manager to add vehicles to the Stand 
	    Scanner sc= new Scanner(System.in);
    	while(true) {
    		System.out.printf("Current monetary fund: %.2f�.\n",stand.getMonetary());
	    	System.out.println("Which type of vehicle you want to add to the stand?\nType Motocycle, Car, Van or Bicycle or S to sell vehices or Q to quit the program.");
	    	if( sc.hasNext()){
	    		String typeVehicle=sc.nextLine().toLowerCase().trim();
	    		String nameVehicle;
	    		switch(typeVehicle) {
	    		case "motocycle":
	    			System.out.println("Which vehicle you want specifically? (type the name of the vehicle)");
	    			nameVehicle=sc.nextLine().toLowerCase().trim();
	    			
	    			stand.addVehicle(twoWheelFactory.getVehicle(VehicleType.MOTORCYCLE, nameVehicle));
	    			break;
	    		case "bicycle":
	    			System.out.println("Which vehicle you want specifically? (type the name of the vehicle)");
	    			nameVehicle=sc.nextLine().toLowerCase().trim();
	    			
	    			stand.addVehicle(twoWheelFactory.getVehicle(VehicleType.BICYCLE, nameVehicle));
	    			break;
	    		case "car":
	    			System.out.println("Which vehicle you want specifically? (type the name of the vehicle)");
	    			nameVehicle=sc.nextLine().toLowerCase().trim();
	    			
	    			stand.addVehicle(fourWheelFactory.getVehicle(VehicleType.CAR, nameVehicle));
	    			break;
	    		case "van":
	    			System.out.println("Which vehicle you want specifically? (type the name of the vehicle)");
	    			nameVehicle=sc.nextLine().toLowerCase().trim();
	    			
	    			stand.addVehicle(fourWheelFactory.getVehicle(VehicleType.VAN, nameVehicle));
	    			break;
	    		case "s":
	    			// ready to sell vehicles
	    			while (true) {
	    		    	if (stand.checkStand()) {
	    		    		String awnser;
	    		    		System.out.printf("Current monetary fund: %.2f�.\n",stand.getMonetary());
	    				    System.out.println("Which of the following vehicles you sold?\nType the number of the vehicle or A to add more vehicles or Q to quit the program.");
	    				    Iterator<Entry<Integer, Vehicle>> it = stand.getVehicles().entrySet().iterator();
	    				    while (it.hasNext()) {
	    						HashMap.Entry<Integer, Vehicle> pair = (HashMap.Entry<Integer, Vehicle>) it.next();
	    				        System.out.println(pair.getKey() + " : " + pair.getValue());
	    				    }
	    				    awnser=sc.next().toLowerCase().trim();
	    				    if (awnser.equals("a")) {
	    				    	break;
	    				    } else if (awnser.equals("q")){
	    				    	System.out.println("Closed program.");
	    	        			sc.close();
	    	    				System.exit(0);
		    				} else {
	    				    	try {
	    				    		int code = Integer.parseInt(awnser);
	    				    		if (stand.checkCode(code)) {
		    				    		stand.sellVehicle(code);
	    				    		} else {
		    			    			System.out.println("Vehicle code doesn't exist!");
	    				    		}
	    			    		} catch( NumberFormatException e) {
	    			    			System.out.println("Invalid awnser!");
	    			    		}
	    				    }
	    		    	} else {
	    		    		System.out.println("Stand has no vehicles.");
	    		    		break;
	    		    	}
	    		    }
	    			break;
	    		case "q":
	    			System.out.println("Closed program.");
	    			sc.close();
	    			System.exit(0);
	    		default:
	    			System.out.println("Invalid type of vehicle.");
	    			break;
	    		}
    		}
	    }
    	
	}
}