package AbstractFactoryPattern;

public class FactoryProducer {
	public static AbstractFactory getVehicleFactory(VehicleFactoryType type){   
		if(VehicleFactoryType.FOURWHEEL == type){
			return new FourWheelFactory();         
		}else if(VehicleFactoryType.TWOWHEEL == type){
			return new TwoWheelFactory();
		}
		return null;
	}
}