package AbstractFactoryPattern;

public class FourWheelFactory extends AbstractFactory {
	public Vehicle getVehicle(VehicleType vehicle, String name){    
		if (VehicleType.CAR == vehicle){
				return new Car(name);         
		}else if(VehicleType.VAN == vehicle){
			return new Van(name);
		}
		return null;
	}
}