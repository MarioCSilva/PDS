package AbstractFactoryPattern;

public class Motorcycle extends Vehicle {
	public Motorcycle(String name) {
		super(name,1600.19);
	}
}