package AbstractFactoryPattern;

import java.util.HashMap;
import java.util.Iterator;

public class Stand {
	private HashMap<Integer,Vehicle> vehicles;
	private HashMap<Integer, Double> vehiclesCost;
	private String name;
	private Double monetary;
	private int index;

	public Stand(String name) {
		this.name=name;
		this.vehicles= new HashMap<>();
		this.vehiclesCost= new HashMap<>();
		this.monetary=0.0;
		this.index=0;
	}
   
	public Boolean checkStand() {
		if (vehicles.size()>0)
			return true;
		else
			return false;
	}

	public void addVehicle(Vehicle vehicle) {
		int code=getIndex();
		this.vehicles.put(code, vehicle);
		this.vehiclesCost.put(code, vehicle.getCost()*4);
		this.monetary=this.monetary-vehicle.getCost();
	}
	
	public void sellVehicle(Integer code) {
		Double profit=getVehiclesCost().remove(code)-getVehicles().remove(code).getCost();
		setMonetary(getMonetary()+profit);
	}
	
	public Boolean checkCode(Integer code) {
        Iterator<HashMap.Entry<Integer, Vehicle>> iterator = vehicles.entrySet().iterator(); 
        while (iterator.hasNext()) { 
            HashMap.Entry<Integer, Vehicle> entry = iterator.next(); 
              if (code == entry.getKey()) { 
            	return true; 
            }
        }
        return false;
	}

	public int getIndex() {
		return this.index++;
	}

	public HashMap<Integer, Double> getVehiclesCost() {
		return vehiclesCost;
	}
	
	public void setVehiclesCost(HashMap<Integer, Double> vehiclesCost) {
		this.vehiclesCost = vehiclesCost;
	}
	
	public Double getMonetary() {
		return monetary;
	}
	
	public void setMonetary(Double monetary) {
		this.monetary = monetary;
	}
	
	public HashMap<Integer, Vehicle> getVehicles() {
		return vehicles;
	}
	
	public void setVehicles(HashMap<Integer, Vehicle> vehicles) {
		this.vehicles = vehicles;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
}
