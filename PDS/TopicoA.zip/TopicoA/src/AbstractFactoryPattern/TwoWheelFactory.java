package AbstractFactoryPattern;

public class TwoWheelFactory extends AbstractFactory {
	public Vehicle getVehicle(VehicleType vehicle, String name){
		if (VehicleType.MOTORCYCLE == vehicle){
				return new Motorcycle(name);
		}else if(VehicleType.BICYCLE == vehicle){
			return new Bicycle(name);
		}
		return null;
	}
}