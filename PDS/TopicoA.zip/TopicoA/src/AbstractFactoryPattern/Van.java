package AbstractFactoryPattern;

public class Van extends Vehicle {
	public Van(String name) {
		super(name,2300.13);
	}
}