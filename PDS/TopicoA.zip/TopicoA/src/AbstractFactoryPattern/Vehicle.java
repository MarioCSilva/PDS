package AbstractFactoryPattern;

public class Vehicle {
	protected String name;
	protected Double cost;
	
	public Vehicle(String name, Double cost) {
		this.name=name;
		this.cost=cost;
	}
	
	public String toString() {
		return this.name;
	}
	
	public Double getCost() {
		return this.cost;
	}
}