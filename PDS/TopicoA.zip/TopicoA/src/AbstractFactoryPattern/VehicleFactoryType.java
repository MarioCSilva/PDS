package AbstractFactoryPattern;

public enum VehicleFactoryType {
	FOURWHEEL,
	TWOWHEEL
}
