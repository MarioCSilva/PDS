package AbstractFactoryPattern;

public enum VehicleType {
	CAR,
	VAN,
	MOTORCYCLE,
	BICYCLE
}
