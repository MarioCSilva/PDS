package IteratorPattern;

import java.util.Scanner;

public class Client {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);

		// create a Mall
		System.out.println("What is the name of the mall you want to manage?");
		String awnser=sc.nextLine().trim();
		Mall mall = new Mall(awnser);
		
		// manage the Mall
		manageMall(sc, mall);
		
		sc.close();
    }
	
	public static void manageMall(Scanner sc, Mall mall) {
		while (true) {
			System.out.println("Would you like to add Stores or see the current Stores of the Mall? (Press A to Add or S to See or Q to Quit)");
			String awnser=sc.nextLine().toLowerCase().trim();
			switch(awnser) {
				case "a":
					System.out.println("What's the name of the Store you wish to add?");
					awnser=sc.nextLine().toLowerCase().trim();
					mall.addStore(new Store(awnser));
					break;
				case "s":
					
					// create iterator to go through Mall's Stores
					System.out.println("Stores of the Mall "+mall.getMallName());
					Iterator storeIterator = mall.createIterator();
					while (storeIterator.hasNext()) {
						Object currentStore = storeIterator.next();
						System.out.print("\t Store: "+currentStore +",  Items: ");

						// create iterator to go through the items of the Store 
						Iterator itemIterator=((Store) currentStore).createIterator();
						while (itemIterator.hasNext()) {
							Object item = itemIterator.next();
							System.out.print(item +" / ");
						}
						System.out.println("\n");
					}
					break;
				case "q":
					System.out.println("Program closed.");
					return;	
				default:
					System.out.println("Invalid awnser.");
					break;
			}
		}
	}
}
