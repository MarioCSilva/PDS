package IteratorPattern;

public interface Collection {
	public Iterator createIterator(); 
}
