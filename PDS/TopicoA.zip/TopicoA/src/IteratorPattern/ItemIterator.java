package IteratorPattern;

import java.util.ArrayList;

public class ItemIterator implements Iterator {
	private ArrayList<Item> itemList;
    private int pos = 0;

    public ItemIterator(ArrayList<Item> itemList) {
    	this.itemList = itemList;
    }

    public Item next() { 
        Item item =  this.itemList.get(pos); 
        this.pos += 1;
        return item;
    }

    public boolean hasNext() { 
        if (this.pos >= this.itemList.size() || this.itemList.get(this.pos) == null) 
            return false;
        else
            return true;
    }
}
