package IteratorPattern;

public class Mall implements Collection {
	private String mallName;
	private Store[] storeList;
	private final static int maxStores=10;
	private int currentStore;
	private int newMax = maxStores; 
	
	public Mall(String mallName) {
		this.setMallName(mallName);
		this.storeList=new Store[newMax];
		addStore(new Store("Puma"));
		addStore(new Store("Adidas"));
		addStore(new Store("Nike"));
		this.currentStore=3;
	}
	
	public boolean addStore(Store storeName) {
		if (storeName == null)
			return false;
		ensureSpace();
		this.storeList[currentStore++]=storeName;
		return true;
	}
	
	private void ensureSpace() {
		if (currentStore >= newMax) {
			newMax += maxStores;
			Store[] newArray = (Store[]) new Object[newMax];
			System.arraycopy(storeList, 0, newArray, 0, currentStore );
			storeList = newArray;
		}
	}
	
	public Iterator createIterator() { 
        return new StoreIterator(storeList); 
    } 
	
	
	public String getMallName() {
		return mallName;
	}
	public void setMallName(String mallName) {
		this.mallName = mallName;
	}
	public Store[] getStoreList() {
		return storeList;
	}
	public void setStoreList(Store[] storeList) {
		this.storeList = storeList;
	}
}
