package IteratorPattern;

import java.util.ArrayList;

public class Store implements Collection {
	private String storeName;
	private ArrayList<Item> itemList = new ArrayList<>();

	
	public Store(String storeName) {
		this.setStoreName(storeName);
		this.itemList.add(new Item(storeName+" Shoes"));
		this.itemList.add(new Item(storeName+" T-Shirts"));
		this.itemList.add(new Item(storeName+" Jeans"));
		this.itemList.add(new Item(storeName+" Jackets"));
	}
	
	public void add(Item item) {
    	this.itemList.add(item);
    }
	
	public Iterator createIterator() { 
        return new ItemIterator(itemList); 
    } 
	
	public String toString() {
		return storeName;
	}

	public ArrayList<Item> getItemList() {
		return itemList;
	}

	public void setItemList(ArrayList<Item> itemList) {
		this.itemList = itemList;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
}