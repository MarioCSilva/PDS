package IteratorPattern;

public class StoreIterator implements Iterator {
	    private Store[] storeList; 
	    private int pos = 0; 

	    public  StoreIterator (Store[] storeList) { 
	        this.storeList = storeList; 
	    }

	    public Store next() { 
	    	Store storeName =  storeList[pos]; 
	        pos += 1; 
	        return storeName; 
	    } 

	    public boolean hasNext() {
	        if (pos >= storeList.length || storeList[pos] == null)
	            return false;
	        else
	            return true;
	    } 
}
